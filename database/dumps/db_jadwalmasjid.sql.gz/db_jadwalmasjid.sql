-- MySQL dump 10.13  Distrib 8.0.42, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: db_jadwalmasjid
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `duitku_callbacks`
--

DROP TABLE IF EXISTS `duitku_callbacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `duitku_callbacks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `merchantOrderId` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `merchantCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `productCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resultCode` int DEFAULT NULL,
  `reference` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signature` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rawJson` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `processed` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `duitku_callbacks_merchantOrderId_idx` (`merchantOrderId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `duitku_callbacks`
--

LOCK TABLES `duitku_callbacks` WRITE;
/*!40000 ALTER TABLE `duitku_callbacks` DISABLE KEYS */;
INSERT INTO `duitku_callbacks` VALUES (1,'ORDER-TEST-1','DUMMY',25000,NULL,0,'HACK','afd1a970cb92a3fb50412dabf323fa8d','merchantOrderId=ORDER-TEST-1&merchantCode=DUMMY&amount=25000&resultCode=00&reference=HACK&signature=afd1a970cb92a3fb50412dabf323fa8d',0,'2026-09-13 08:46:59.888'),(6,'X','DUMMY',1,NULL,0,'','abc','merchantOrderId=X&merchantCode=DUMMY&amount=1&resultCode=00&signature=abc',0,'2026-09-13 12:48:02.225'),(7,'X','DUMMY',1,NULL,0,'','abc','merchantOrderId=X&merchantCode=DUMMY&amount=1&resultCode=00&signature=abc',0,'2026-09-13 12:50:48.039');
/*!40000 ALTER TABLE `duitku_callbacks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `productId` int NOT NULL,
  `productName` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitPrice` int NOT NULL,
  `qty` int NOT NULL,
  `lineTotal` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_orderId_idx` (`orderId`),
  KEY `order_items_productId_fkey` (`productId`),
  CONSTRAINT `order_items_orderId_fkey` FOREIGN KEY (`orderId`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_items_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (10,10,2,'Paket Hemat 32\"',3899000,1,3899000),(11,11,1,'Paket Mesin',860000,1,860000),(12,12,1,'Paket Mesin',860000,1,860000);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_status_logs`
--

DROP TABLE IF EXISTS `order_status_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_status_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `status` enum('PENDING_PAYMENT','PAID','PROCESSING','SHIPPED','COMPLETED','CANCELLED','EXPIRED') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `order_status_logs_orderId_idx` (`orderId`),
  CONSTRAINT `order_status_logs_orderId_fkey` FOREIGN KEY (`orderId`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_status_logs`
--

LOCK TABLES `order_status_logs` WRITE;
/*!40000 ALTER TABLE `order_status_logs` DISABLE KEYS */;
INSERT INTO `order_status_logs` VALUES (19,10,'PENDING_PAYMENT','Pesanan dibuat, menunggu pembayaran','2026-09-14 07:17:29.335'),(20,11,'PENDING_PAYMENT','Pesanan dibuat, menunggu pembayaran','2026-09-14 07:23:21.097'),(21,12,'PENDING_PAYMENT','Pesanan dibuat, menunggu pembayaran','2026-09-14 07:23:23.040');
/*!40000 ALTER TABLE `order_status_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderNumber` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` int NOT NULL,
  `status` enum('PENDING_PAYMENT','PAID','PROCESSING','SHIPPED','COMPLETED','CANCELLED','EXPIRED') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING_PAYMENT',
  `subtotal` int NOT NULL,
  `shippingFee` int NOT NULL,
  `total` int NOT NULL,
  `duitkuReference` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duitkuPaymentUrl` varchar(600) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentChannel` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paidAt` datetime(3) DEFAULT NULL,
  `expiryAt` datetime(3) NOT NULL,
  `recipientName` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiverMosqueName` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `postalCode` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `courier` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trackingNumber` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_orderNumber_key` (`orderNumber`),
  KEY `orders_userId_idx` (`userId`),
  CONSTRAINT `orders_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (10,'JM-20260914-822252',6,'PENDING_PAYMENT',3899000,250000,4149000,NULL,NULL,NULL,NULL,'2026-09-15 07:17:29.298','register operasional','081882883700','test duitku','kebon jeruk ','jakarta barat','dki jakarta','12310',NULL,NULL,NULL,'2026-09-14 07:17:29.318','2026-09-14 07:17:29.318'),(11,'JM-20260914-137637',5,'PENDING_PAYMENT',860000,75000,935000,NULL,NULL,NULL,NULL,'2026-09-15 07:23:21.075','hendra wijaya','085156602781','Test Masjid','telaga bestari e1 19, tangerang','jakarta','Jakarta','15660','test',NULL,NULL,'2026-09-14 07:23:21.079','2026-09-14 07:23:21.079'),(12,'JM-20260914-237404',5,'PENDING_PAYMENT',860000,75000,935000,NULL,NULL,NULL,NULL,'2026-09-15 07:23:23.027','hendra wijaya','085156602781','Test Masjid','telaga bestari e1 19, tangerang','jakarta','Jakarta','15660','test',NULL,NULL,'2026-09-14 07:23:23.028','2026-09-14 07:23:23.028');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `slug` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtitle` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `price` int NOT NULL,
  `originalPrice` int DEFAULT NULL,
  `badge` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isFeatured` tinyint(1) NOT NULL DEFAULT '0',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `stock` int NOT NULL DEFAULT '0',
  `weightGrams` int NOT NULL DEFAULT '1000',
  `shippingFee` int NOT NULL DEFAULT '0',
  `imageKey` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sortOrder` int NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_key` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'paket-mesin','Paket Mesin','Wakaf TV box jadwal sholat untuk masjid yang sudah punya TV','Hibahkan Android TV Box Jadwal Masjid (RAM 2GB) sebagai amal jariyah yang terus mengalir. Isi paket: 1 unit TV box + kabel HDMI pendek & adaptor daya, aplikasi sudah terpasang siap colok & jalan. Untuk TV 32–65 inch, auto-boot langsung ke jadwal sholat, stabil 24 jam, 100% offline tanpa internet. Termasuk garansi & dukungan pemasangan.',860000,1200000,NULL,0,1,48,1500,75000,'tv1.webp',1,'2026-09-11 17:03:05.758','2026-09-14 07:23:23.021'),(2,'paket-hemat-32','Paket Hemat 32\"','Wakaf TV 32 inch siap pasang untuk musholla & masjid mini','Wakaf satu paket TV LED 32 inch baru (Full HD, DVB-T2) garansi resmi sebagai amal jariyah untuk musholla & masjid mini. Termasuk bracket dinding & kabel terpasang rapi di balik TV, plus gratis setting nama masjid & koordinat. Plug & play, tinggal colok listrik, cocok kapasitas 2–4 saf.',3899000,4800000,NULL,0,1,19,12500,250000,'tv2.webp',2,'2026-09-11 17:03:05.836','2026-09-14 07:17:29.292'),(3,'paket-layar-besar-40','Paket Layar Besar 40\"','Wakaf unggulan untuk masjid jami & paket wakaf','Wakaf TV LED 40 inch baru (Full HD 1080p) garansi resmi untuk masjid jami — amal jariyah terbaik. Termasuk bracket heavy duty & kabel rapi tersembunyi, gratis nama masjid, logo & running text wakaf. Teks jelas terbaca dari saf belakang, packing kayu + asuransi pengiriman.',4999000,6200000,'Terlaris',1,1,15,18000,350000,'hero.webp',3,'2026-09-11 17:03:05.877','2026-09-12 05:12:39.071');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `googleId` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatarUrl` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mosqueName` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mosqueAddress` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postalCode` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('CUSTOMER','ADMIN') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CUSTOMER',
  `profileCompleted` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_googleId_key` (`googleId`),
  UNIQUE KEY `users_email_key` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'dummy-penguji@jadwalmasjid.id','penguji@jadwalmasjid.id','penguji',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CUSTOMER',0,'2026-09-11 18:47:52.164','2026-09-13 08:40:33.707'),(3,'dummy-admin@jadwalmasjid.com','admin@jadwalmasjid.com','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ADMIN',0,'2026-09-12 04:58:25.277','2026-09-13 08:44:17.825'),(5,'109141295305164280355','emailhendra2@gmail.com','hendra wijaya','https://lh3.googleusercontent.com/a/ACg8ocKjFd0yB2qpEeo-fggovyk5WzXuBvAP88gKZ6coKQflDQbBUtzE=s96-c','085156602781','Test Masjid','test','Tangerang','tangerang','15660','ADMIN',1,'2026-09-13 12:02:30.843','2026-09-14 07:22:20.648'),(6,'110988316286204716637','registermerchant@gmail.com','register operasional','https://lh3.googleusercontent.com/a/ACg8ocJwKze8Sc2FCATfLAEcyeMmNTqgAGQEYZhOqtGp-nM-aqpqEw=s96-c','081882883700','test duitku','kebon jeruk ','jakarta barat','dki jakarta','12310','CUSTOMER',1,'2026-09-14 07:16:41.950','2026-09-14 07:17:24.837');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'db_jadwalmasjid'
--

--
-- Dumping routines for database 'db_jadwalmasjid'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15 23:30:55
